# Guided prompts for Lovable and Bolt

The Claude Code skills in this kit are step-by-step procedures. Lovable and Bolt can't load them, so this file breaks the same procedures into prompts you paste into the chat, one at a time: planning a new feature (section 0), the security and launch checks (1 to 5), and a slop check (6).

## How to use this file

1. **Add the rules first.** Paste `lovable-bolt-instructions-full.md` (or the short version) into your project knowledge. The prompts below assume the AI has those rules.
2. **Save a checkpoint** before each section: GitHub sync, or note the current version in the tool's history, so you can roll back.
3. **Use the tool's planning or discussion mode** (the mode where it answers without editing code) for every prompt marked *Plan*. Switch back to normal mode only for prompts marked *Build*, after you've read the plan.
4. **One prompt at a time.** Read the answer before sending the next one. If the answer doesn't match what the prompt asked for (no table, no list, it started editing), say "Stop. Follow my previous message exactly" and paste it again.
5. Anything in `<angle brackets>` is for you to fill in.

Some steps need the Supabase dashboard. Open your project at supabase.com, then **SQL Editor** in the left sidebar. The queries mentioned below are in this kit at `skills/supabase-rls-audit/sql/rls-status.sql`. Open that file in any text editor and copy the numbered query you need.

---

## 0. Before building anything new

Use this for every new feature, page or flow. Skip it for small fixes.

### 0.1 Plan (*Plan*)

```
I want to build: <describe it in your own words: who uses it and what they can do>.
Don't write any code yet. First look at what already exists in this project, then write a short plan with these sections:
1. Goal, and what we're NOT building in this version.
2. The main user flow, as numbered steps.
3. Data: new or changed tables and columns, with the column that says who owns each row. Only add things; list anything that deletes or renames data separately.
4. Access: a table showing who can see, create, edit and delete rows in each table (anyone / logged-in users / only the owner / team members / admins). Which columns are private. Which columns users must never change themselves (role, plan, credits).
5. What must run in an Edge Function instead of the browser (payments, prices, emails, API keys, AI calls).
6. Each page: what it shows, and its loading, empty and error states. Which existing components you'll reuse.
7. Edge cases: double clicks, two tabs, deleted items, very long text, no items, slow internet, phone screens.
8. How we'll test it, including as a logged-out visitor and as a second user.
9. Small build steps, in order, that each leave the app working.
Ask me up to 5 questions whose answers would change the plan, with your suggested answer for each.
```

Read the plan properly. The Data and Access sections are the expensive ones to change later: check that each table has an owner and that "who can see what" matches what you want.

### 0.2 Build one step at a time (*Build*)

```
The plan is approved. Build only step <n>. Use the existing components and styles. When you're done, tell me what changed, what isn't finished yet, and how to test this step.
```

Test each step before asking for the next one. If the AI says the code doesn't match the plan, have it update the plan before carrying on.

---

## 1. Database security audit (do this first on an existing app)

The anon key in your app is visible to anyone who opens your site. Row Level Security (RLS) is the only thing stopping them from reading or changing your data with it.

### 1.1 Map the data (*Plan*)

```
Don't change any code. List every Supabase table this app uses, in a table with these columns:
table | what it stores | who should be able to READ it | who should be able to CREATE/EDIT/DELETE rows | the column that identifies the owner (user_id, team_id...) | does it contain private info (email, phone, address, payment)?
Use: "anyone", "any logged-in user", "only the owner", "team members", "admins only".
Also list every storage bucket and every database function the app calls with rpc().
Mark anything you're unsure about with a question for me.
```

Check the answers. This table is the rulebook for everything after it, so correct anything that's wrong.

### 1.2 See the real state of your database (you, in Supabase)

In the SQL Editor, run **query 1** from `rls-status.sql`, then **query 2**, then **queries 3 to 6**, one at a time.

- **Good:** every row in query 1 shows `rls_enabled` = `true`.
- **Bad:** any `false`. That table is open to anyone with your anon key.
- **Bad:** `true` in `using_expression` or `with_check_expression` on an INSERT, UPDATE or DELETE policy in query 2.
- **Bad:** `{public}` in `roles` on anything that isn't meant to be public.
- **Bad:** `security_invoker` = `false` in query 3, any row at all in query 4, or `public` = `true` in query 6 for a bucket with user files.

Copy each result (the SQL Editor has a copy/export button) for the next step.

### 1.3 Review (*Plan*)

```
Don't change any code yet. Here is the current state of my Supabase database security:

QUERY 1 (tables and RLS):
<paste>

QUERY 2 (policies):
<paste>

QUERIES 3-6 (views, security definer functions, storage policies, buckets):
<paste>

Compare this with the access table from your previous answer and with the project knowledge rules. Give me a findings table: table | problem | severity (Critical / High / Medium) | fix in plain English.
Critical: RLS off, true in a write policy, secret key in frontend code, admin checks using user_metadata, public views without security_invoker, security definer functions without an auth.uid() check.
High: update policies without with check, insert policies that don't check the owner, private columns in public tables, users able to change their own role/plan, public buckets with user files, storage policies that don't check the user's folder.
Medium: bare auth.uid() instead of (select auth.uid()), policies without "to authenticated", missing indexes on user_id / team_id.
Also say which app features would break if RLS were turned on with no policies, so we don't break them.
```

### 1.4 Fix (*Build*)

```
Write ONE migration that fixes every Critical and High finding from your table, following the project knowledge rules. Order: enable RLS, drop the policies being replaced, create the new policies, add indexes.
Before running it, show me the full SQL and list:
- any step that deletes or moves data (wait for my OK on those)
- any app code that must change for the app to keep working (for example, reading a column from a different table)
Then make the app code changes in the smallest way possible. Don't change anything else.
```

### 1.5 Test as an attacker (you, in Supabase)

Replace `<table>` with each of your tables and run this in the SQL Editor. It pretends to be a logged-out visitor and changes nothing:

```sql
begin;
  set local role anon;
  select count(*) from public.<table>;
rollback;
```

- **Good:** `0` for every table that isn't meant to be public.
- **Bad:** any other number. Paste the result back into the chat and ask the AI to fix that table.

Then test as a real second user:

1. Sign up two accounts, A and B (use `yourname+a@gmail.com` and `yourname+b@gmail.com`: both arrive in your inbox).
2. Log in as A in your normal browser and create some data.
3. Log in as B in a private window. B must not see A's data anywhere. Try opening A's pages by pasting their URLs into B's window.
4. As B, try to edit or delete A's things through the app.

If anything of A's shows up for B, paste what you saw into the chat with: `User B can see <what>. Find which policy allows it and fix only that.`

Finally, in Supabase open **Advisors > Security Advisor** and ask the AI to fix anything it lists.

---

## 2. Keys and secrets (*Plan*)

```
Don't change any code. Search the whole project for secrets:
1. Every environment variable the code reads, and whether it's public (VITE_ or NEXT_PUBLIC_ prefix).
2. Any key that looks like sb_secret_, service_role, sk_live_, sk_test_, sk-ant-, sk-proj-, or a long eyJ... token, anywhere in frontend code, config or committed .env files.
3. Any Edge Function or server route that uses a secret key, and whether it checks who the user is before doing anything.
Give me a table: what you found | where | risk | fix. If you find a secret in frontend code, tell me first: I'll need to rotate it.
```

If anything is found: rotate the key in its dashboard (Supabase: Project Settings > API Keys; Stripe, OpenAI and so on in theirs) **before** fixing the code. Deleting it from the code isn't enough; it may already have been copied.

---

## 3. Sign-up, login and emails

### 3.1 Dashboard settings (you, in Supabase)

In **Authentication > URL Configuration**:
- **Site URL** = your live domain (`https://yourapp.com`), not localhost and not the preview URL.
- **Redirect URLs** include `https://yourapp.com/**` and your preview/editor URL pattern.

In **Authentication > Emails** (SMTP settings): set up custom SMTP (Resend, Postmark, Amazon SES...). Supabase's built-in sender is for testing: real users often never get the email.

### 3.2 Review (*Plan*)

```
Don't change any code. Check this app's auth against the project knowledge rules:
- every signUp, signInWithOtp, resetPasswordForEmail and signInWithOAuth call: does it pass a redirect built from window.location.origin?
- what the user sees after sign-up when email confirmation is on
- what happens when someone signs up with an email that already exists
- how many Supabase clients are created
- whether protected pages wait for the session check before redirecting to login
- whether the reset password page exists, calls updateUser, and isn't redirected away by a route guard
- what the user sees when an email link has expired (error_description in the URL)
Give me a table: flow | what happens now | problem | fix.
```

### 3.3 Fix one flow at a time (*Build*)

```
Fix only the <sign-up / login / password reset / email confirmation / Google login> problems from your table. Smallest change possible. Then give me a step-by-step test for that flow on the live site.
```

To use the kit's ready-made pages, paste the contents of `templates/vite/src/pages/AuthConfirm.tsx` or `ResetPassword.tsx` into the chat after this prompt and add: `Use this file as the pattern, adapted to how this project is structured.`

### 3.4 Test on the live site (you)

In a private window, with a new `+tag` email each time: sign up → confirm email → log in → refresh the page (still logged in?) → log out → forgot password → set a new one → log in with it. Also open a confirmation email on your phone while you signed up on the laptop.

---

## 4. Before launch (*Plan*)

```
Don't change any code. Do a pre-launch check and report PASS, FAIL (with the fix) or CAN'T CHECK (with what I should check by hand) for each:
1. The project builds with no errors or type errors.
2. Refreshing any page on the live site works (SPA rewrite in vercel.json or _redirects, if the host needs it).
3. Unknown URLs show a proper 404 page.
4. An error boundary shows a friendly message if a component crashes.
5. Every Supabase call checks error.
6. Every page that loads data has loading, error and empty states.
7. Submit buttons are disabled while saving.
8. No console.log prints user data or tokens.
9. Favicon, page titles and a social preview image are set.
10. Privacy policy and terms pages exist if we collect personal data or take payments.
11. If we take payments: prices and access are decided on the server, and the Stripe webhook verifies its signature.
Put every FAIL first, most serious first.
```

Then fix the FAILs one at a time with: `Fix only item <n>. Smallest change. Tell me how to test it.` (*Build*)

---

## 5. Google, link previews and AI search (*Plan*)

First, see what crawlers see. In Chrome, open `view-source:https://yourapp.com/pricing` (with your domain and a real page). If you can't find your page's title and text in there, most AI crawlers and link previews can't either.

```
Don't change any code. My public pages are: <home, pricing, about, blog...>.
For each, tell me what's in the raw HTML (title, description, h1, text) vs what appears only after JavaScript runs.
Then give me options to make these pages readable without JavaScript (for example prerendering at build time), with the trade-offs of each for this project and for where it's hosted. Don't pick one for me.
Also list what's missing from: unique titles and descriptions, canonical URLs, Open Graph tags with an absolute image URL, robots.txt, sitemap.xml, noindex on logged-in pages.
```

After you've chosen an option: `Implement <option> and the missing tags, for the public pages only. Then tell me how to verify it.` (*Build*)

Check a link preview by pasting your URL into a WhatsApp or LinkedIn message draft (don't send it).

---

## 6. Slop check (*Plan*)

Run this after a feature is built, and before launch on the whole app.

```
Don't change any code. Review <this feature / the pages we changed today / the whole app> for AI slop and give me a table: problem | where (file and line) | why it matters | fix.
Check for:
1. Unfinished work presented as done: stubs, TODOs, hardcoded results, errors that are caught and hidden so the screen looks fine, fake or sample data in real screens.
2. Things that don't exist: packages that aren't installed, functions that don't exist in them, environment variables that aren't set up.
3. Duplicates: a second Supabase client, two versions of the same component or helper, copy-pasted code, unused files, commented-out code, debug logs.
4. Over-complication: extra layers or files for something used once.
5. UI: hardcoded colours or sizes instead of the theme, inconsistent buttons, spacing or fonts, missing loading/empty/error states, removed focus outlines, anything broken at phone width, the generic AI look (purple gradients, emoji icons, three identical cards).
6. Content: lorem ipsum, invented testimonials, user counts, ratings or logos, filler words (unlock, seamless, revolutionise, elevate), buttons that say "Submit", errors that only say "Something went wrong".
Put the most serious first. Also list what you checked and found clean, and any placeholder that needs real content from me.
```

Then fix in batches: `Fix only the <category> findings. Don't change anything else. Tell me how to check nothing broke.` (*Build*)

Placeholders like testimonials, prices and user counts need real content from you. Don't let the AI invent them.

---

## After any change

Paste this whenever the AI says something is done:

```
Before we move on: what exactly did you change (files and what each change does)? What did you verify, and how? What should I test by hand, as a logged-out visitor and as a second user? Is there anything I must do in Supabase, Vercel, Netlify or Stripe settings? Anything you noticed but didn't fix?
```
