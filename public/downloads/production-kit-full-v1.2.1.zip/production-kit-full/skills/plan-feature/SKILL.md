---
name: plan-feature
description: Plan a new feature, page, flow or app before writing any code, and get the user's approval. Use when the user asks to build, add or create something new ("add team invites", "let users upload files", "build a booking page", "let's start the app"), or describes what users should be able to do. Produces a short spec covering data, access rules, pages and their states, edge cases, acceptance criteria and a step-by-step build plan. For bug fixes and small changes, use safe-change instead.
---

# Plan a feature before building it

The most expensive mistakes in AI-built apps are made before the first line of code: a table with no owner column, access rules bolted on after real data exists, a page with no empty state, a second copy of a component that already existed. A short plan the user has read catches these while they're free to fix.

Skip this skill for copy changes, styling tweaks and one-line fixes. Say so, and use `safe-change`.

## Step 1: Understand the request and the codebase

Read before asking anything:
- `package.json`, the router, the Supabase client file(s), `supabase/migrations/` (or run the table and policy queries from `sql/rls-status.sql` in the `supabase-rls-audit` skill's folder).
- Existing components, hooks and utilities in the area you'll touch. List the ones the feature can reuse.
- Any existing plans in `docs/plans/`.

Then restate the request in two or three sentences: who uses it, what they can do, and what "done" looks like.

Ask only the questions whose answers change the plan, at most five, and give a default for each so the user can reply "go with the defaults". Good questions: who can see this (only the owner, the team, everyone)? Can it be edited or deleted after it's created? Is it free for everyone or tied to a plan? Bad questions: anything you can find out by reading the code.

## Step 2: Write the plan

Save it as `docs/plans/<yyyy-mm-dd>-<feature>.md` and show it to the user. Size it to the feature: a small feature gets a page, not a document. Use these sections, and write "none" rather than dropping a section:

```markdown
# <Feature>

## Goal
One sentence. Then "Not in this version:" with the things you're deliberately leaving out.

## User flow
Numbered steps of the main journey, from where the user starts to the result they see.

## Data
For each new or changed table: columns with types, the owner column (user_id / team_id),
not null, defaults, check constraints, foreign keys with on delete behaviour, indexes.
Changes to existing tables are additive (new columns, new tables). Anything destructive is
listed separately and needs explicit approval.

## Access (becomes RLS)
| table | select | insert | update | delete |
|---|---|---|---|---|
| e.g. invites | team members | team admins | nobody | team admins |
Also: private columns and where they live, columns users must never change themselves
(role, plan, credits, owner), storage buckets and folder rules.

## Server-side
What must not run in the browser: prices and payments, sending emails, third-party API keys,
AI calls, anything granting access. Where each runs (Edge Function, route handler, database
trigger) and what input it validates.

## Pages and components
For each route: what it shows, and its loading, empty, error and no-permission states.
Existing components reused (by name). New components needed, and why an existing one won't do.

## Edge cases
Double submit, two tabs editing the same thing, parent deleted, very long text, zero / one /
many items, slow network, session expiring mid-flow, mobile width. Only the ones that apply,
each with what should happen.

## Acceptance criteria
A checklist someone can test by hand, including: a logged-out visitor can't reach the data,
a second user can't see or change the first user's data, and the empty state on a new account.

## Build steps
Ordered, small steps that each leave the app working (for example: 1. migration with RLS,
2. data hooks, 3. list page with states, 4. create form, 5. edit and delete). For each:
files touched and how to verify it.

## Open questions
Anything still undecided.
```

Plan the access rules at the same time as the tables. Every table gets its RLS policies in the same migration that creates it.

## Step 3: Get approval

Stop after showing the plan. Don't write code until the user approves it or asks for changes. If they say "just build it", keep at least Data, Access and Build steps: those are the parts that are expensive to change later.

## Step 4: Build one step at a time

Follow the `safe-change` skill for each build step: smallest diff, run the build, verify the step, suggest a commit. After each step, tick it off in the plan file.

If the code turns out different from what the plan assumed (an existing table, a component that already does this, a constraint you missed), stop and update the plan with the user. Don't quietly build something different from what they approved.

## Step 5: Finish

Walk through every acceptance criterion and report the actual result of each: passed (how you checked), failed, or needs a manual check (exact steps). Run the `slop-check` skill on the feature's changes. Update the plan file with anything that changed and a "Follow-ups" list.
