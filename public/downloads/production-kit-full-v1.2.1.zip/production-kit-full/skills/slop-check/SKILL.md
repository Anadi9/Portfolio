---
name: slop-check
description: Review code changes or a feature for AI slop before committing or shipping. Finds work that looks finished but isn't (stubs, TODOs, fake success, mock data in real screens), invented packages or APIs, duplicated components, dead code, needless abstraction, noisy comments, generic AI-looking UI, placeholder content and filler copy. Use after the AI builds a feature, before a commit or pull request, or when the user says the code feels bloated, messy, inconsistent or "AI-generated", or the app "looks like every other AI app".
---

# Slop check

Slop is output that looks finished but isn't, or that adds code without adding value. It's why AI-built apps get harder to change with every prompt: each new request lands on top of stubs, duplicates and dead ends from the last one.

## Rules for this review

- **Report first, fix only with approval.** Fixes follow the `safe-change` skill: smallest diff, behaviour unchanged unless the finding is a bug.
- **Evidence for every finding:** file and line, what's there, and why it matters. No vague "could be cleaner".
- **Scope:** by default, the current changes: `git diff` plus `git diff main...HEAD` (use the repo's main branch name). Review a named folder or feature if the user asks. Don't review the whole repo unless asked; on a big codebase it produces a list nobody acts on.

List the files in scope first:

```bash
git diff --name-only; git diff --name-only main...HEAD
```

Run the searches below on those files. They use plain `grep -E` and work on macOS and Linux; in Claude Code you can run the same patterns with the built-in search tool. `$FILES` means the list of changed source files (for example `FILES=$(git diff --name-only main...HEAD -- '*.ts' '*.tsx' '*.js' '*.jsx' '*.css')`).

## A. Fake "done" (most serious)

Work presented as complete that doesn't do what it claims.

- Stubs and placeholders: functions that return hardcoded values, handlers that only `console.log`, `throw new Error("Not implemented")`, `// TODO`, `// implement later`, `// in a real app...`.
- Fake success: a `catch` that returns success or an empty result so the UI looks fine when the request failed.
- Mock or sample data wired into real screens: arrays of fake users, `John Doe`, `Jane Smith`, `Acme`, `lorem ipsum`, `example.com`, `placeholder`, `sample`, `dummy`, `mock` outside test files.
- Claims check: re-read the AI's last summary of what it built. For every claim ("added validation", "handles errors", "sends the email"), find the code that does it. Report each claim with no matching code.
- Tests that are skipped, assert nothing, or mock the very thing they're meant to test.

```bash
grep -HnEi "TODO|FIXME|XXX|not implemented|implement (this|later)|in a real app|placeholder|lorem ipsum|john doe|jane (doe|smith)|example\.com|dummy|mock(ed)?[A-Z_ (]|sample data" $FILES
grep -HnE "catch *(\([^)]*\))? *\{ *\}|catch *(\([^)]*\))? *\{[^}]*return (true|\[\]|\{\}|null)" $FILES
grep -HnE "\.(skip|only)\(|expect\(true\)" $FILES
```

## B. Invented things

- Imports of packages that aren't in `package.json`, or packages added to `package.json` that nothing imports.
- Methods, options or props that don't exist in the installed version of a library. The type check catches most of these.
- Environment variables read in code but missing from `.env.example`.

```bash
npx tsc --noEmit                        # if the project uses TypeScript
npx knip                                # unused files, exports and dependencies, unlisted packages
grep -rhoE "(import\.meta\.env|process\.env)\.[A-Z0-9_]+" src app lib 2>/dev/null | sort -u
```

`knip` runs through `npx` and downloads on first use: say so before running it. If a finding depends on a library's API, check the installed package's types in `node_modules` or its docs rather than memory.

## C. Duplication and dead weight

- A new component, hook or utility that duplicates an existing one: a second `Button`, `Modal`, `formatDate`, `useAuth`, fetch wrapper or Supabase client. Search the codebase for the name and for what it does.
- Copy-pasted blocks that differ by a value or two.
- Files nothing imports, unused exports, commented-out code (code that was switched off, not usage examples in doc comments), leftover `console.log` / `debugger`.

```bash
grep -rlE "createClient\(|createBrowserClient\(" src app lib 2>/dev/null   # more than one browser client is a bug
grep -HnE "console\.(log|debug)|debugger" $FILES
grep -HnE "^[[:space:]]*//[[:space:]]*(const |let |var |return |import |export |await |if ?\(|\}|[A-Za-z_.]+\(.*\);?$)" $FILES   # commented-out code
```

## D. Over-engineering

- An abstraction with one user: a `Service`, `Manager`, `Factory`, `Repository` or generic wrapper around Supabase with a single caller. Inline it. Rule of thumb: abstract when there are three real uses, not before.
- Config options and parameters nothing sets, generic types with one concrete use, a custom hook that wraps one line.
- A state library, form library or UI kit added for something the project already handles.
- Defensive code that hides real errors: `?? []` or optional chaining on values that can't be missing, try/catch around code that can't throw.

## E. Noise

- Comments that restate the code (`// set loading to true`) or narrate the change (`// Updated to fix the bug`, `// As requested`, `// Here's the new version`). Keep comments that explain why.
- Emoji in code, logs or commit messages; banner comments; long JSDoc on trivial functions.
- Names and file layout that don't match the rest of the codebase.

```bash
grep -HnEi "//.*(as requested|updated to|changed to|here'?s the|now we|this (fixes|ensures)|added (this|the))" $FILES
perl -CSD -ne 'print "$ARGV:$.: $_" if /[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}]/; close ARGV if eof' $FILES   # emoji
```

## F. UI slop

- The generic AI look: purple or indigo-to-pink gradients by default, glassmorphism, emoji used as icons, every page a centred hero with three identical feature cards, decorative animation on everything.
- Off-system values: hardcoded hex colours and pixel sizes instead of the project's theme (Tailwind config, CSS variables, component library). Arbitrary Tailwind values like `w-[347px]` or `text-[13px]`.
- Too many variants: several button styles, font sizes or border radii where the design has one or two. Mixed icon sets.
- Missing states: loading, empty and error views; disabled and loading buttons; focus styles removed (`outline-none` / `focus:outline-none` with no `focus-visible` replacement).
- Breaks at 375px wide, tap targets under 44px, text on images without enough contrast.

```bash
grep -HnE "#[0-9a-fA-F]{3,8}([^0-9a-zA-Z]|$)|rgba?\(" $(echo $FILES | tr ' ' '\n' | grep -E "\.(tsx|jsx)$")
grep -hoE "[a-z:-]+-\[[^]]+\]" $FILES | sort | uniq -c | sort -rn | head -30
grep -HnE "from-(purple|indigo|violet|fuchsia|pink)-[0-9]+|backdrop-blur" $FILES
grep -HnE "(focus:)?outline-none" $FILES
```

## G. Copy slop

- Filler phrases: "unlock", "seamless(ly)", "revolutionise", "elevate", "supercharge", "cutting-edge", "game-changer", "in today's fast-paced world", "whether you're a ... or a ...", "take your ... to the next level".
- Fake social proof: invented testimonials, user counts, ratings or customer logos.
- Vague labels: "Submit", "Click here", "Get started" on every button. Buttons should say what they do ("Save changes", "Send invite").
- Error messages that say only "Something went wrong" when the code knows what happened and what the user can do.

```bash
grep -HnEi "unlock|seamless|revolutioni[sz]e|elevate|supercharge|cutting-edge|game-?changer|fast-paced|next level|whether you'?re" $FILES
grep -HnEi "[0-9][0-9,]*\+? (happy )?(users|customers|teams)|★|testimonial" $FILES
```

## Report

1. **Summary:** count of findings per category, and a one-line verdict.
2. **Findings table**, most serious first (A, B, then F and G because users see them, then C, D, E):

| # | Category | File:line | What's there | Why it matters | Fix | Effort |
|---|---|---|---|---|---|---|

3. **Checked and clean:** the categories and searches that found nothing, so the user knows what was covered.
4. **Needs the user:** placeholders that need real content (copy, images, testimonials, prices) that only they can provide.

Then ask which findings to fix. Fix in batches by category, run the build and the project's checks after each batch, and suggest a commit per batch.
