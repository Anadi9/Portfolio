// Goes in: src/pages/ResetPassword.tsx, routed at /reset-password
// (NOT inside ProtectedRoute, and make sure no guard redirects logged-in
// users away from it: the recovery link logs the user in first).
//
// Flow:
// 1. Your "forgot password" form calls requestPasswordReset(email) below.
// 2. The email link signs the user in with a recovery session and lands here
//    (directly, or via /auth/confirm if you use the token-hash templates).
// 3. This page calls supabase.auth.updateUser({ password }).
//
// Add https://yourdomain.com/reset-password (and localhost) to
// Supabase Dashboard > Authentication > URL Configuration > Redirect URLs.

import { useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { supabase, authRedirect } from "../lib/supabase";
import { useAuth } from "../auth/AuthProvider";

const MIN_LENGTH = 8; // Match Authentication > Providers > Email > minimum password length.

export async function requestPasswordReset(email: string): Promise<string | null> {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: authRedirect("/reset-password"),
  });
  // Show the same message whether or not the email exists, so the form
  // can't be used to find out who has an account.
  return error ? "Something went wrong. Try again in a minute." : null;
}

export default function ResetPassword() {
  const { session, loading } = useAuth();
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (loading) return <main aria-busy="true" style={{ padding: 24 }}>Loading…</main>;

  if (!session) {
    return (
      <main style={{ maxWidth: 420, margin: "64px auto", padding: 16 }}>
        <h1>Link expired</h1>
        <p>This reset link has expired or was already used. Request a new one from the log in page.</p>
        <p><a href="/login">Back to log in</a></p>
      </main>
    );
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (password.length < MIN_LENGTH) return setError(`Use at least ${MIN_LENGTH} characters.`);
    if (password !== confirm) return setError("The two passwords don't match.");

    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) {
      setError(error.message);
      return;
    }
    navigate("/dashboard", { replace: true });
  }

  return (
    <main style={{ maxWidth: 420, margin: "64px auto", padding: 16 }}>
      <h1>Choose a new password</h1>
      <form onSubmit={onSubmit}>
        <label>
          New password
          <input type="password" autoComplete="new-password" value={password}
            onChange={(e) => setPassword(e.target.value)} required minLength={MIN_LENGTH} />
        </label>
        <label>
          Repeat new password
          <input type="password" autoComplete="new-password" value={confirm}
            onChange={(e) => setConfirm(e.target.value)} required minLength={MIN_LENGTH} />
        </label>
        {error && <p role="alert">{error}</p>}
        <button type="submit" disabled={busy}>{busy ? "Saving…" : "Save new password"}</button>
      </form>
    </main>
  );
}
