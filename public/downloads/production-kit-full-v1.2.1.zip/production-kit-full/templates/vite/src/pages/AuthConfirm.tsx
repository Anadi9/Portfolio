// Goes in: src/pages/AuthConfirm.tsx, routed at /auth/confirm (NOT inside
// ProtectedRoute).
//
// Why this page exists: email security scanners (Outlook Safe Links, corporate
// gateways) open links in emails before the user does. With Supabase's default
// links, the scanner uses up the one-time token and the user sees "Email link
// is invalid or has expired". Here, the link only opens this page; the token is
// used when the user clicks the button. It also works when the link is opened
// on a different device from the one used to sign up.
//
// Setup, in Supabase Dashboard > Authentication > Emails (templates):
//   Confirm signup:
//     <a href="{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=email&next=/dashboard">Confirm your email</a>
//   Magic link:
//     <a href="{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=email&next=/dashboard">Log in</a>
//   Reset password:
//     <a href="{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=recovery&next=/reset-password">Reset your password</a>
//   Change email address:
//     <a href="{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=email_change&next=/settings">Confirm new email</a>
// Site URL (Authentication > URL Configuration) must be your production domain.

import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import type { EmailOtpType } from "@supabase/supabase-js";
import { supabase } from "../lib/supabase";
import { safeNextPath } from "../auth/ProtectedRoute";

const OTP_TYPES: EmailOtpType[] = ["email", "signup", "magiclink", "recovery", "invite", "email_change"];

// Supabase appends ?error_description=... (or #error_description=...) when a
// link fails. Turn the common ones into something a person can act on.
function humanError(raw: string | null): string | null {
  if (!raw) return null;
  const text = raw.replace(/\+/g, " ");
  if (/expired|invalid/i.test(text)) {
    return "This link has expired or was already used. Request a new one and use the latest email.";
  }
  return text;
}

export default function AuthConfirm() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);

  const hash = new URLSearchParams(window.location.hash.slice(1));
  const linkError = humanError(params.get("error_description") ?? hash.get("error_description"));
  const [error, setError] = useState<string | null>(linkError);

  const tokenHash = params.get("token_hash");
  const typeParam = params.get("type") as EmailOtpType | null;
  const type = typeParam && OTP_TYPES.includes(typeParam) ? typeParam : null;
  const next = safeNextPath(window.location.search, type === "recovery" ? "/reset-password" : "/dashboard");

  async function confirm() {
    if (!tokenHash || !type) return;
    setBusy(true);
    setError(null);
    const { error } = await supabase.auth.verifyOtp({ token_hash: tokenHash, type });
    setBusy(false);
    if (error) {
      setError(humanError(error.message));
      return;
    }
    navigate(next, { replace: true });
  }

  if (error) {
    return (
      <main style={{ maxWidth: 420, margin: "64px auto", padding: 16 }}>
        <h1>That link didn't work</h1>
        <p role="alert">{error}</p>
        <p><a href="/login">Back to log in</a></p>
      </main>
    );
  }

  if (!tokenHash || !type) {
    return (
      <main style={{ maxWidth: 420, margin: "64px auto", padding: 16 }}>
        <h1>Link incomplete</h1>
        <p>This link is missing some information. Open the most recent email from us and click the button again.</p>
      </main>
    );
  }

  return (
    <main style={{ maxWidth: 420, margin: "64px auto", padding: 16 }}>
      <h1>{type === "recovery" ? "Reset your password" : "Confirm your email"}</h1>
      <p>Click the button to continue.</p>
      <button type="button" onClick={confirm} disabled={busy}>
        {busy ? "Checking…" : "Continue"}
      </button>
    </main>
  );
}
