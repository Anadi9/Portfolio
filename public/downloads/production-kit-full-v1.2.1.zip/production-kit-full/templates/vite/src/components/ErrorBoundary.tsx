// Goes in: src/components/ErrorBoundary.tsx
// Wrap your app (outside the router is fine):
//   <ErrorBoundary><AuthProvider><App /></AuthProvider></ErrorBoundary>
// A crash in any component then shows a friendly screen instead of a blank
// white page.
//
// To send crashes to an error tracker, pass onError, e.g. with Sentry:
//   <ErrorBoundary onError={(e) => Sentry.captureException(e)}>
//
// Error boundaries don't catch errors in event handlers or async code (a
// failed fetch). Handle those where they happen and show an error state.

import { Component, type ErrorInfo, type ReactNode } from "react";

type Props = {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, info: ErrorInfo) => void;
};

type State = { error: Error | null };

export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    if (import.meta.env.DEV) console.error(error, info.componentStack);
    this.props.onError?.(error, info);
  }

  render() {
    if (!this.state.error) return this.props.children;
    if (this.props.fallback) return this.props.fallback;
    return (
      <main role="alert" style={{ maxWidth: 480, margin: "64px auto", padding: 16 }}>
        <h1>Something went wrong</h1>
        <p>Sorry about that. Reloading the page usually fixes it. If it keeps happening, contact us.</p>
        <button type="button" onClick={() => window.location.reload()}>Reload</button>
      </main>
    );
  }
}
