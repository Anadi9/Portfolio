// Goes in: src/auth/AuthProvider.tsx
// Wrap your app once, above the router's routes:
//   <AuthProvider><App /></AuthProvider>
//
// What this gets right:
// - One onAuthStateChange subscription for the whole app, cleaned up on unmount.
// - `loading` stays true until Supabase reports INITIAL_SESSION, so route
//   guards never redirect to /login before the session has been read
//   (the cause of "logged out on refresh" and redirect loops).
// - No `await supabase...` inside the callback: that can deadlock the auth
//   client. Do follow-up queries in a useEffect that depends on `user`.

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { AuthChangeEvent, Session, User } from "@supabase/supabase-js";
import { supabase } from "../lib/supabase";

type AuthState = {
  session: Session | null;
  user: User | null;
  loading: boolean;
  lastEvent: AuthChangeEvent | null;
};

const AuthContext = createContext<AuthState | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>({
    session: null,
    user: null,
    loading: true,
    lastEvent: null,
  });

  useEffect(() => {
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      // Synchronous state updates only. See the note at the top of the file.
      setState({
        session,
        user: session?.user ?? null,
        loading: false,
        lastEvent: event,
      });
    });
    return () => data.subscription.unsubscribe();
  }, []);

  return <AuthContext.Provider value={state}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>.");
  return ctx;
}
