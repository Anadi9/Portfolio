// Goes in: src/auth/ProtectedRoute.tsx
// Usage with React Router (v6 or v7):
//   <Route element={<ProtectedRoute />}>
//     <Route path="/dashboard" element={<Dashboard />} />
//   </Route>
//
// - Shows a loading state while the session is being read. Never redirects
//   during loading.
// - Sends logged-out users to /login?next=<where they were going>, so your
//   login page can send them back after signing in.
//
// This only hides screens. Real protection is RLS in the database: a
// logged-out user can still call your API directly.

import type { ReactNode } from "react";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "./AuthProvider";

type Props = {
  loginPath?: string;
  fallback?: ReactNode;
};

export function ProtectedRoute({ loginPath = "/login", fallback }: Props) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <>{fallback ?? <div aria-busy="true" style={{ padding: 24 }}>Loading…</div>}</>;
  }

  if (!user) {
    const next = encodeURIComponent(location.pathname + location.search);
    return <Navigate to={`${loginPath}?next=${next}`} replace />;
  }

  return <Outlet />;
}

// On your login page, after a successful sign-in, send the user back.
// Only allow same-site paths, so ?next= can't redirect to another domain.
export function safeNextPath(search: string, fallback = "/dashboard"): string {
  const next = new URLSearchParams(search).get("next");
  return next && next.startsWith("/") && !next.startsWith("//") ? next : fallback;
}
