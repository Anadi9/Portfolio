// Goes in: src/lib/env.ts
// Reads every public env var in one place and fails loudly at startup if one
// is missing, instead of letting `undefined` reach the Supabase client and
// fail later with a confusing error.
//
// Everything here is PUBLIC (VITE_ prefix = shipped to the browser).
// Never add a secret to this file.

function required(name: string, value: string | undefined): string {
  if (!value || value.trim() === "") {
    throw new Error(
      `Missing environment variable ${name}. Add it to .env.local (and to your host's environment settings), then restart or redeploy.`,
    );
  }
  return value;
}

export const env = {
  supabaseUrl: required("VITE_SUPABASE_URL", import.meta.env.VITE_SUPABASE_URL),
  supabasePublishableKey: required(
    "VITE_SUPABASE_PUBLISHABLE_KEY",
    import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
  ),
  siteUrl: import.meta.env.VITE_SITE_URL ?? window.location.origin,
} as const;

// Guard against the most expensive mistake: a secret key in a VITE_ variable.
if (
  env.supabasePublishableKey.startsWith("sb_secret_") ||
  env.supabasePublishableKey.includes("service_role")
) {
  throw new Error(
    "VITE_SUPABASE_PUBLISHABLE_KEY holds a secret key. Use the publishable/anon key, and rotate the secret key now: it has been exposed.",
  );
}
