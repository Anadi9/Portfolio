// Goes in: src/lib/supabase.ts
// The ONE Supabase client for the whole app. Import it everywhere:
//   import { supabase } from "@/lib/supabase";
// Creating more than one client causes lost sessions and
// "Multiple GoTrueClient instances" warnings.
//
// Optional: pass your generated types for typed queries:
//   import type { Database } from "@/types/database";
//   createClient<Database>(...)

import { createClient } from "@supabase/supabase-js";
import { env } from "./env";

export const supabase = createClient(env.supabaseUrl, env.supabasePublishableKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

// Build auth redirect URLs from the current origin so the same code works on
// localhost, preview deploys and production. Every origin you use must be in
// Supabase Dashboard > Authentication > URL Configuration > Redirect URLs.
export function authRedirect(path: string): string {
  return new URL(path, window.location.origin).toString();
}
