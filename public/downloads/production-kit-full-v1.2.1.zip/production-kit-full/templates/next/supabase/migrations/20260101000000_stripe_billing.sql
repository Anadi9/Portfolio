-- Goes in: supabase/migrations/<timestamp>_stripe_billing.sql
-- (rename with: supabase migration new stripe_billing, then paste this in)
--
-- Two tables used by app/api/stripe/webhook/route.ts:
--   stripe_events  - every processed Stripe event id, so retries are ignored
--   entitlements   - what each user has paid for; the app reads this
-- Only the server (secret key) writes to them. Users can read their own
-- entitlement row and nothing else.

create table if not exists public.stripe_events (
  id          text primary key,              -- Stripe event id (evt_...)
  type        text not null,
  received_at timestamptz not null default now()
);
alter table public.stripe_events enable row level security;
-- No policies: anon and authenticated users can't read or write this table.

create table if not exists public.entitlements (
  user_id             uuid primary key references auth.users (id) on delete cascade,
  plan                text not null default 'free',
  status              text not null default 'inactive',  -- Stripe subscription status
  stripe_customer_id  text unique,
  stripe_subscription_id text unique,
  current_period_end  timestamptz,
  updated_at          timestamptz not null default now()
);
alter table public.entitlements enable row level security;

create policy "entitlements: owner can read" on public.entitlements
  for select to authenticated
  using ((select auth.uid()) = user_id);
-- No insert/update/delete policies: only the webhook (secret key) changes plans.
