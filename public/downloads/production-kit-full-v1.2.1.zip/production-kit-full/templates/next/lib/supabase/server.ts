// Goes in: lib/supabase/server.ts
// Supabase client for Server Components, Server Actions and Route Handlers.
// Create a new one per request: `const supabase = await createClient();`
//
// To know who the user is on the server, use `supabase.auth.getClaims()` or
// `supabase.auth.getUser()`. Never trust `getSession()` on the server: it
// reads the cookie without verifying it.

import "server-only";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options),
            );
          } catch {
            // Called from a Server Component, where cookies are read-only.
            // Safe to ignore: proxy.ts refreshes the session on every request.
          }
        },
      },
    },
  );
}
