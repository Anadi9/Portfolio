// Goes in: lib/supabase/client.ts (or src/lib/supabase/client.ts)
// Supabase client for Client Components ("use client").
// Uses only public env vars. Never import the secret key into a client file.

import { createBrowserClient } from "@supabase/ssr";

export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY!,
  );
}
