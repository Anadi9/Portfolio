// Goes in: lib/supabase/admin.ts
// Admin client using the SECRET key. It bypasses Row Level Security, so:
// - only import it from server code (route handlers, server actions, webhooks)
// - never from a Client Component; `server-only` makes the build fail if you do
// - always decide yourself which user's rows you touch; RLS won't stop you

import "server-only";
import { createClient } from "@supabase/supabase-js";

export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const secret = process.env.SUPABASE_SECRET_KEY;
  if (!url || !secret) {
    throw new Error("Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SECRET_KEY.");
  }
  return createClient(url, secret, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
