// Goes in: app/auth/confirm/route.ts
// Handles the token-hash email links (confirm signup, magic link, reset
// password, email change). The token-hash flow works when the link is opened on a different device.
//
// Email templates (Supabase Dashboard > Authentication > Emails), e.g.:
//   Confirm signup:  {{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=email&next=/dashboard
//   Reset password:  {{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=recovery&next=/reset-password
//
// If your users' email scanners (Outlook, corporate gateways) burn links
// before users click them, switch this GET handler to render a page with a
// "Continue" button that calls verifyOtp, as in the Vite AuthConfirm template.

import type { EmailOtpType } from "@supabase/supabase-js";
import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(request: NextRequest) {
  const { searchParams, origin } = request.nextUrl;
  const tokenHash = searchParams.get("token_hash");
  const type = searchParams.get("type") as EmailOtpType | null;
  const nextParam = searchParams.get("next") ?? "/dashboard";
  // Same-site paths only, so ?next= can't send users to another domain.
  const next = nextParam.startsWith("/") && !nextParam.startsWith("//") ? nextParam : "/dashboard";

  if (tokenHash && type) {
    const supabase = await createClient();
    const { error } = await supabase.auth.verifyOtp({ type, token_hash: tokenHash });
    if (!error) {
      return NextResponse.redirect(new URL(next, origin));
    }
  }

  const url = new URL("/login", origin);
  url.searchParams.set("error", "This link has expired or was already used. Request a new one.");
  return NextResponse.redirect(url);
}
