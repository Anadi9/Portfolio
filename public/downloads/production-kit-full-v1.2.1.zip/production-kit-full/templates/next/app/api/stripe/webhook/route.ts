// Goes in: app/api/stripe/webhook/route.ts
// Needs: STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, SUPABASE_SECRET_KEY
// and the migration in supabase/migrations/..._stripe_billing.sql.
//
// What this gets right:
// - Verifies Stripe's signature on the raw body before trusting anything.
// - Idempotent: each event id is recorded once, so Stripe's retries don't
//   grant access twice.
// - Access is decided here, on the server, from Stripe's data. Never from a
//   price or plan the browser sends.
//
// When you create the Checkout Session (server side), link it to the user:
//   stripe.checkout.sessions.create({
//     mode: "subscription",
//     client_reference_id: user.id,                      // from getClaims(), not the request body
//     subscription_data: { metadata: { user_id: user.id } },
//     line_items: [{ price: "price_...", quantity: 1 }],
//     success_url: `${siteUrl}/billing?success=1`,
//     cancel_url: `${siteUrl}/billing`,
//   })
//
// Register the endpoint in Stripe Dashboard > Developers > Webhooks for your
// production URL with these events: checkout.session.completed,
// customer.subscription.created, customer.subscription.updated,
// customer.subscription.deleted. Test locally with:
//   stripe listen --forward-to localhost:3000/api/stripe/webhook

import Stripe from "stripe";
import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Created on first use, not at import time, so a build without the env var
// doesn't crash.
let stripeClient: Stripe | null = null;
function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) throw new Error("Missing STRIPE_SECRET_KEY.");
  return (stripeClient ??= new Stripe(key));
}

// Map your Stripe price ids to plan names. Edit to match your products.
const PLAN_BY_PRICE: Record<string, string> = {
  // "price_123": "pro",
};

export async function POST(request: Request) {
  const signature = request.headers.get("stripe-signature");
  if (!signature) return NextResponse.json({ error: "Missing signature" }, { status: 400 });

  // The signature is computed over the raw body: read it as text, not JSON.
  const body = await request.text();

  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secret) {
    console.error("Missing STRIPE_WEBHOOK_SECRET.");
    return NextResponse.json({ error: "Server misconfigured" }, { status: 500 });
  }

  let event: Stripe.Event;
  try {
    event = getStripe().webhooks.constructEvent(body, signature, secret);
  } catch {
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  const db = createAdminClient();

  // Record the event first. A duplicate id means Stripe is retrying one we
  // already handled: acknowledge it and do nothing.
  const { error: insertError } = await db
    .from("stripe_events")
    .insert({ id: event.id, type: event.type });
  if (insertError) {
    if (insertError.code === "23505") return NextResponse.json({ received: true, duplicate: true });
    console.error("stripe_events insert failed", insertError.message);
    return NextResponse.json({ error: "Storage error" }, { status: 500 });
  }

  try {
    await handleEvent(event, db);
  } catch (err) {
    // Forget the event so Stripe's retry gets processed, then report failure.
    await db.from("stripe_events").delete().eq("id", event.id);
    console.error("Stripe webhook handling failed", event.type, err);
    return NextResponse.json({ error: "Handler error" }, { status: 500 });
  }

  return NextResponse.json({ received: true });
}

async function handleEvent(event: Stripe.Event, db: ReturnType<typeof createAdminClient>) {
  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object;
      const userId = session.client_reference_id;
      if (!userId) throw new Error(`Checkout session ${session.id} has no client_reference_id`);
      const customerId = typeof session.customer === "string" ? session.customer : session.customer?.id;
      const { error } = await db.from("entitlements").upsert({
        user_id: userId,
        stripe_customer_id: customerId ?? null,
        updated_at: new Date().toISOString(),
      });
      if (error) throw new Error(error.message);
      break;
    }

    case "customer.subscription.created":
    case "customer.subscription.updated":
    case "customer.subscription.deleted": {
      const sub = event.data.object;
      const userId = sub.metadata?.user_id;
      if (!userId) throw new Error(`Subscription ${sub.id} has no metadata.user_id`);
      const item = sub.items.data[0];
      const priceId = item?.price.id;
      const active = sub.status === "active" || sub.status === "trialing";
      const { error } = await db.from("entitlements").upsert({
        user_id: userId,
        plan: active && priceId ? (PLAN_BY_PRICE[priceId] ?? "paid") : "free",
        status: sub.status,
        stripe_customer_id: typeof sub.customer === "string" ? sub.customer : sub.customer.id,
        stripe_subscription_id: sub.id,
        current_period_end: item?.current_period_end
          ? new Date(item.current_period_end * 1000).toISOString()
          : null,
        updated_at: new Date().toISOString(),
      });
      if (error) throw new Error(error.message);
      break;
    }

    default:
      // Ignore events you didn't subscribe to.
      break;
  }
}
