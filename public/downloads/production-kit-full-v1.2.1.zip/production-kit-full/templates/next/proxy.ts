// Goes in: proxy.ts in the project root (or src/proxy.ts), next to app/.
//
// Next.js 16+ calls this file proxy.ts and the function `proxy`.
// On Next.js 15 or older: name the file middleware.ts and rename the
// function below to `middleware`. Everything else stays the same.

import type { NextRequest } from "next/server";
import { updateSession } from "./lib/supabase/proxy";

export async function proxy(request: NextRequest) {
  return updateSession(request);
}

export const config = {
  // Run on everything except static files and images, so auth logic
  // can't block CSS, JS or images from loading.
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|robots.txt|sitemap.xml|.*\\.(?:svg|png|jpg|jpeg|gif|webp|avif|ico)$).*)",
  ],
};
