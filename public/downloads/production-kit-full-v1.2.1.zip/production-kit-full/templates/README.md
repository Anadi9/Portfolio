# Templates

Drop-in files that implement the rules in `CLAUDE.md`. Each file starts with a comment saying where it goes and what to change. Copy only what you need, then ask your AI tool to wire it into your app following the patterns already there.

Checked against @supabase/supabase-js 2.117, @supabase/ssr 0.12, Next.js 16.3, React 19, React Router 7, Vite 8 and stripe 22 (typecheck and production build pass). If you're on older versions, the ideas hold but some names may differ.

## Any stack

| File | Goes in | What it does |
|---|---|---|
| `vercel.json` | project root | SPA rewrite so deep links don't 404 on refresh (Vite + React Router on Vercel). Not needed for Next.js. |
| `netlify/_redirects` | `public/_redirects` | The same rewrite for Netlify. |
| `public/robots.txt` | `public/robots.txt` | Allows crawlers, blocks logged-in routes, points to your sitemap. Replace `example.com`. |
| `scripts/generate-sitemap.ts` | `scripts/` | Writes `public/sitemap.xml` from your public routes at build time. |

## Vite + React (Lovable, Bolt, v0 exports)

| File | Goes in | What it does |
|---|---|---|
| `vite/.env.example` | project root | Every variable name, which ones are public, no values. |
| `vite/src/lib/env.ts` | `src/lib/` | Reads env vars in one place, fails loudly if one is missing, refuses to start with a secret key in a `VITE_` variable. |
| `vite/src/lib/supabase.ts` | `src/lib/` | The single Supabase client, plus `authRedirect()` for redirect URLs that work on every domain. |
| `vite/src/auth/AuthProvider.tsx` | `src/auth/` | One auth listener for the app; `loading` until the session is known; no deadlock-prone awaits in the callback. |
| `vite/src/auth/ProtectedRoute.tsx` | `src/auth/` | Route guard that never redirects while loading, and sends users back where they were after login. |
| `vite/src/pages/AuthConfirm.tsx` | `src/pages/` | Confirm-email / magic-link / reset landing page. Survives email scanners and different devices. Includes the email template links to paste into Supabase. |
| `vite/src/pages/ResetPassword.tsx` | `src/pages/` | New-password form, plus `requestPasswordReset()` for your "forgot password" form. |
| `vite/src/components/ErrorBoundary.tsx` | `src/components/` | Friendly fallback instead of a white screen when a component crashes. |

## Next.js (App Router)

| File | Goes in | What it does |
|---|---|---|
| `next/.env.example` | project root | Public vs server-only variables, clearly separated. |
| `next/lib/supabase/client.ts` | `lib/supabase/` | Client for Client Components. |
| `next/lib/supabase/server.ts` | `lib/supabase/` | Client for Server Components, Server Actions and Route Handlers. |
| `next/lib/supabase/admin.ts` | `lib/supabase/` | Secret-key client for server code only (`server-only` breaks the build if a client file imports it). |
| `next/lib/supabase/proxy.ts` | `lib/supabase/` | Refreshes the session cookie on every request and redirects logged-out users from private pages. |
| `next/proxy.ts` | project root | Calls the above. Next.js 16 name; on Next.js 15 rename to `middleware.ts` and the function to `middleware`. |
| `next/app/auth/confirm/route.ts` | `app/auth/confirm/` | Handles token-hash email links (confirm, magic link, reset). |
| `next/app/api/stripe/webhook/route.ts` | `app/api/stripe/webhook/` | Stripe webhook: verifies the signature, ignores retries, grants access from Stripe's data on the server. |
| `next/supabase/migrations/..._stripe_billing.sql` | `supabase/migrations/` | Tables for the webhook, with RLS: users can read their own plan, only the server can change it. |

The `@/` imports in the Next.js files assume the default `"@/*": ["./*"]` path alias. If your project uses `src/`, it's `"@/*": ["./src/*"]`; adjust the imports if you have no alias.

After copying files, run `npm run build` and fix anything your project names differently. The templates are starting points: read the comments before shipping them.
