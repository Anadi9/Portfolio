// Goes in: scripts/generate-sitemap.ts
// Writes public/sitemap.xml from a list of public routes, at build time.
// Add to package.json:
//   "scripts": { "sitemap": "tsx scripts/generate-sitemap.ts",
//                "build": "npm run sitemap && vite build" }
// (install tsx once: npm i -D tsx)
//
// List only public, indexable pages. Never logged-in pages.
// For pages that come from your database (blog posts, listings), fetch their
// slugs here with the publishable key and add them to `routes`.

import { writeFileSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";

const SITE_URL = (process.env.VITE_SITE_URL ?? process.env.SITE_URL ?? "https://example.com").replace(/\/$/, "");

type Route = { path: string; changefreq?: "daily" | "weekly" | "monthly" | "yearly"; priority?: number };

const routes: Route[] = [
  { path: "/", changefreq: "weekly", priority: 1.0 },
  { path: "/pricing", changefreq: "monthly", priority: 0.8 },
  { path: "/about", changefreq: "yearly", priority: 0.5 },
];

function escapeXml(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

const today = new Date().toISOString().slice(0, 10);
const urls = routes
  .map((r) => {
    const loc = escapeXml(SITE_URL + (r.path === "/" ? "/" : r.path));
    return [
      "  <url>",
      `    <loc>${loc}</loc>`,
      `    <lastmod>${today}</lastmod>`,
      r.changefreq ? `    <changefreq>${r.changefreq}</changefreq>` : "",
      r.priority !== undefined ? `    <priority>${r.priority.toFixed(1)}</priority>` : "",
      "  </url>",
    ].filter(Boolean).join("\n");
  })
  .join("\n");

const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls}
</urlset>
`;

const out = resolve(process.cwd(), process.env.SITEMAP_OUT ?? "public/sitemap.xml");
mkdirSync(dirname(out), { recursive: true });
writeFileSync(out, xml);
console.log(`Wrote ${routes.length} URLs to ${out}`);
