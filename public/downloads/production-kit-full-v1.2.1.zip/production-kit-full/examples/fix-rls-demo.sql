-- ============================================================================
-- Fix migration for the demo schema (examples/insecure-demo-schema.sql).
-- This is the kind of file the supabase-rls-audit skill writes. In a real
-- project it goes in supabase/migrations/<timestamp>_fix_rls.sql.
-- Order: enable RLS, drop the bad policies, create the right ones, indexes.
-- ============================================================================

-- 1. tasks: RLS was off. Tasks belong to the project owner.
alter table public.tasks enable row level security;

create policy "tasks: owner can select" on public.tasks
  for select to authenticated using ((select auth.uid()) = user_id);
create policy "tasks: owner can insert" on public.tasks
  for insert to authenticated
  with check (
    (select auth.uid()) = user_id
    and exists (select 1 from public.projects p
                where p.id = project_id and p.owner_id = (select auth.uid()))
  );
create policy "tasks: owner can update" on public.tasks
  for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
create policy "tasks: owner can delete" on public.tasks
  for delete to authenticated using ((select auth.uid()) = user_id);

-- 2. projects: "members edit projects" let any logged-in user edit any project.
drop policy if exists "members edit projects" on public.projects;
drop policy if exists "owners read projects" on public.projects;
create policy "projects: owner can select" on public.projects
  for select to authenticated using ((select auth.uid()) = owner_id);
create policy "projects: owner can update" on public.projects
  for update to authenticated
  using ((select auth.uid()) = owner_id)
  with check ((select auth.uid()) = owner_id);

-- 3. profiles: emails were public, and users could change their own role.
--    Move private columns out of the public table, and stop users writing role.
create table public.profile_private (
  id    uuid primary key references public.profiles (id) on delete cascade,
  email text
);
alter table public.profile_private enable row level security;
create policy "profile_private: owner can select" on public.profile_private
  for select to authenticated using ((select auth.uid()) = id);
insert into public.profile_private (id, email) select id, email from public.profiles;
alter table public.profiles drop column email;   -- destructive: data copied above first

drop policy if exists "profiles are public" on public.profiles;
drop policy if exists "users update own profile" on public.profiles;
create policy "profiles: anyone can read" on public.profiles
  for select to anon, authenticated using (true);  -- only public columns remain
create policy "profiles: owner can update" on public.profiles
  for update to authenticated
  using ((select auth.uid()) = id)
  with check ((select auth.uid()) = id);
-- RLS controls rows, not columns: use column privileges so users can only
-- update their display name, never their role.
revoke update on public.profiles from anon, authenticated;
grant update (display_name) on public.profiles to authenticated;

-- 4. invoices: admin check used user_metadata, which users can edit.
--    Use app_metadata (only the server can set it) instead.
--    Set it with the secret key: supabase.auth.admin.updateUserById(id, { app_metadata: { role: "admin" } })
drop policy if exists "admins read invoices" on public.invoices;
create policy "invoices: owner or admin can select" on public.invoices
  for select to authenticated
  using (
    (select auth.uid()) = user_id
    or ((select auth.jwt()) -> 'app_metadata' ->> 'role') = 'admin'
  );

-- 5. project_stats view ran as its owner and ignored RLS.
alter view public.project_stats set (security_invoker = true);

-- 6. delete_project: SECURITY DEFINER with no ownership check. It doesn't
--    need to bypass RLS at all: make it run as the caller.
create or replace function public.delete_project(p_id uuid) returns void
language sql security invoker set search_path = '' as $$
  delete from public.projects where id = p_id and owner_id = (select auth.uid());
$$;
create policy "projects: owner can delete" on public.projects
  for delete to authenticated using ((select auth.uid()) = owner_id);
revoke execute on function public.delete_project(uuid) from anon, public;

-- 7. Storage: private bucket, uploads only into your own folder.
update storage.buckets
  set public = false,
      file_size_limit = 5242880,                                  -- 5 MB
      allowed_mime_types = array['image/png', 'image/jpeg', 'image/webp']
  where id = 'uploads';
drop policy if exists "logged in users upload" on storage.objects;
create policy "uploads: insert own folder" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'uploads'
              and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "uploads: read own folder" on storage.objects
  for select to authenticated
  using (bucket_id = 'uploads'
         and (storage.foldername(name))[1] = (select auth.uid())::text);

-- 8. Indexes on every foreign key / policy column.
create index if not exists projects_owner_id_idx on public.projects (owner_id);
create index if not exists tasks_project_id_idx  on public.tasks (project_id);
create index if not exists tasks_user_id_idx     on public.tasks (user_id);
create index if not exists invoices_user_id_idx  on public.invoices (user_id);
