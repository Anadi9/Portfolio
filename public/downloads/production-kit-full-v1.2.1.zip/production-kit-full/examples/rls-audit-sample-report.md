# Sample report: Supabase RLS audit

> **Demo on fictional data.** This is the report the `supabase-rls-audit` skill produces, run against `insecure-demo-schema.sql`: a made-up task app with two made-up users, Asha and Ben. No real project or client is involved. The query output below is real: the schema, the status queries and the attack tests were run on Postgres 16 with a minimal stand-in for Supabase's `auth` and `storage` schemas. You can reproduce it on a throwaway Supabase project with the three files in this folder (never a real one).

## Summary

The app looks fine when you click through it, but anyone with the public anon key (it's in every visitor's browser) can read every task and every user's email, and delete other people's projects. Logged-in users can make themselves admins, read every invoice and upload files into other users' folders.

**5 critical, 4 high, 2 medium.** One migration fixes all of them without breaking what Asha and Ben are supposed to be able to do (tests T7a–T7e below).

## Step 1: Current state (from `sql/rls-status.sql`)

Query 1, tables:

```
 table_name | rls_enabled | policy_count
------------+-------------+--------------
 tasks      | f           |            0
 invoices   | t           |            1
 profiles   | t           |            2
 projects   | t           |            2
```

Query 2, policies (trimmed for width):

```
 tablename | policyname               | roles           | cmd    | using_expression                                      | with_check
-----------+--------------------------+-----------------+--------+-------------------------------------------------------+-----------
 invoices  | admins read invoices     | {authenticated} | SELECT | ((auth.jwt() -> 'user_metadata') ->> 'role') = 'admin'  |
 profiles  | profiles are public      | {public}        | SELECT | true                                                  |
 profiles  | users update own profile | {public}        | UPDATE | (auth.uid() = id)                                     |
 projects  | owners read projects     | {authenticated} | SELECT | (auth.uid() = owner_id)                               |
 projects  | members edit projects    | {authenticated} | UPDATE | true                                                  | true
```

Queries 3–7: view `project_stats` has `security_invoker = false`; function `delete_project` is `SECURITY DEFINER` in `public` with no `search_path`; bucket `uploads` is `public = t` with no size or type limit; its only upload policy checks `bucket_id` alone; 4 foreign keys have no index.

## Step 3: Findings

| # | Table / object | Problem | Severity | Fix |
|---|---|---|---|---|
| 1 | `tasks` | RLS disabled. Anyone with the anon key reads and writes every task (T1a: 3 of 3). | Critical | Enable RLS; owner-only policies. |
| 2 | `profiles` | Publicly readable, and holds `email`. RLS filters rows, not columns (T1b: both emails). | Critical | Move `email` to owner-only `profile_private`. |
| 3 | `project_stats` view | Runs as its owner, so it ignores RLS on `projects` and `tasks` (T1c: 2 projects visible to anon). | Critical | `security_invoker = true`. |
| 4 | `delete_project()` | `SECURITY DEFINER`, callable by anon via `rpc()`, no ownership check (T1d–e: anon deleted Ben's project). | Critical | Make it `security invoker`, check the owner, revoke from anon. |
| 5 | `invoices` | "Admin" check reads `user_metadata`, which every user can edit with `updateUser()` (T5: Ben sees 2 of 2). | Critical | Check `app_metadata` (server-only) instead. |
| 6 | `profiles` | Update policy lets users change any column, including `role` (T4: Ben made himself `admin`). No `with check`, no role target. | High | Column privileges: users may update `display_name` only. Add `with check`, `to authenticated`. |
| 7 | `projects` | `members edit projects` is `using (true)` for updates. T2 is blocked today only because the select policy hides Asha's rows from Ben; at the database level, an update with no filter changed both projects in testing, and any future broader select policy (e.g. teams) opens it fully. | High | Owner-only update with `using` and `with check`. |
| 8 | `storage.objects` | Upload policy doesn't check the folder (T6: Ben uploaded into Asha's folder). | High | Check `(storage.foldername(name))[1] = auth.uid()`. |
| 9 | `uploads` bucket | Public bucket for user files: every file is readable by anyone with the URL. No size or type limit. | High | Private bucket, signed URLs, 5 MB limit, image types only. |
| 10 | all policies | Bare `auth.uid()` (evaluated per row). | Medium | `(select auth.uid())`. |
| 11 | FKs | No index on `projects.owner_id`, `tasks.project_id`, `tasks.user_id`, `invoices.user_id` (slow joins and slow policy checks). | Medium | Add indexes. |

## Step 4: Fix

Migration: [`fix-rls-demo.sql`](fix-rls-demo.sql). Order: enable RLS, drop the bad policies, create owner-scoped ones, move private columns, fix the view and function, lock down storage, add indexes.

One destructive step: `profiles.email` is dropped **after** being copied to `profile_private`. In a real project the skill asks before running this.

App code changes this needs (listed, not made):
- Anywhere the app reads `profiles.email`, read `profile_private.email` instead (the owner only).
- Serve uploads with `createSignedUrl()` instead of public URLs.
- Set admin roles with the secret key (`auth.admin.updateUserById(id, { app_metadata: { role: "admin" } })`), never from the browser.

## Step 5: Test results

From [`rls-attack-tests.sql`](rls-attack-tests.sql). Every test runs in a transaction that is rolled back.

| Test | Before | After |
|---|---|---|
| T1a anon reads tasks | 3 | **0** |
| T1b anon reads emails | asha@example.com, ben@example.com | **no email column** |
| T1c anon reads `project_stats` | 2 | **0** |
| T1d–e anon calls `delete_project` on Ben's project | called; projects left: 1 of 2 | **ERROR: permission denied for function delete_project** |
| T2 Ben renames Asha's project (filtered) | 0 rows changed | 0 rows changed |
| T3 Ben reads tasks (he owns 1) | 3 visible | **1 visible** |
| T4 Ben sets his own role | admin | **ERROR: permission denied for table profiles** |
| T5 Ben reads invoices after editing `user_metadata` | 2 visible | **1 visible** (his own) |
| T6 Ben uploads into Asha's folder | allowed | **ERROR: new row violates row-level security policy for table "objects"** |
| T7a Asha reads her projects | 1 | 1 |
| T7b Asha reads her tasks | 3 (includes Ben's) | **2** (hers only) |
| T7c Asha renames her project | 1 row changed | 1 row changed |
| T7d Asha uploads into her own folder | allowed | allowed |
| T7e Asha changes her display name | 1 row changed | 1 row changed |

After the fix, `rls-status.sql` shows RLS on for all 5 tables, every policy targeted at `authenticated` (or `anon, authenticated` for the public profile read) with `(select auth.uid())`, `security_invoker = true` on the view, no `SECURITY DEFINER` functions in `public`, a private bucket with limits, and no unindexed foreign keys.

**On a real Supabase project, also run** (with only the public key, as an attacker would):

```bash
curl "https://<project-ref>.supabase.co/rest/v1/tasks?select=*" -H "apikey: <ANON_OR_PUBLISHABLE_KEY>"
# before: 3 rows   after: []
```

Then check Dashboard > Advisors > Security Advisor is clear.

## Step 6: What you must do

1. Run the migration (`supabase db push`, or paste into the SQL Editor and save it to `supabase/migrations/`).
2. Make the app changes listed in Step 4, then redeploy.
3. Files already uploaded to the public bucket may have been seen or saved by others. If they were sensitive, tell the affected users.
4. Re-run `rls-attack-tests.sql`-style checks after any future schema change.
