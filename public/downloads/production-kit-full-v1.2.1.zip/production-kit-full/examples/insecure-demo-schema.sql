-- ============================================================================
-- DEMO ONLY: a deliberately insecure schema for a fictional task app.
-- It exists so you can see what the supabase-rls-audit skill finds and how
-- the fixes look. Every mistake here is a real, common one.
--
-- Never run this in a real project. To try it on Supabase, create a new
-- throwaway project and paste this into the SQL Editor.
-- ============================================================================

-- Two demo users (Asha and Ben), inserted directly so the demo is
-- self-contained. If this insert fails on your Supabase project, create two
-- users in Authentication > Users instead, and replace the ...000a / ...000b
-- ids throughout these files with theirs.
insert into auth.users (id, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-00000000000a', 'asha@example.com', '{"role": "user"}'),
  ('00000000-0000-0000-0000-00000000000b', 'ben@example.com',  '{"role": "user"}');

-- Profiles: public display names... and private columns next to them.
create table public.profiles (
  id           uuid primary key references auth.users (id) on delete cascade,
  display_name text not null,
  email        text,                                  -- private, but in a public table
  role         text not null default 'user'           -- users can change this themselves
);
alter table public.profiles enable row level security;
create policy "profiles are public" on public.profiles
  for select using (true);                            -- no role: applies to anon too
create policy "users update own profile" on public.profiles
  for update using (auth.uid() = id);                 -- no with check, no role, bare auth.uid()

-- Projects: owner-only reads, but anyone logged in can edit any project.
create table public.projects (
  id         uuid primary key default gen_random_uuid(),
  owner_id   uuid not null references auth.users (id),
  name       text not null,
  created_at timestamptz not null default now()
);
alter table public.projects enable row level security;
create policy "owners read projects" on public.projects
  for select to authenticated using (auth.uid() = owner_id);
create policy "members edit projects" on public.projects
  for update to authenticated using (true) with check (true);

-- Tasks: RLS never enabled.
create table public.tasks (
  id         uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects (id) on delete cascade,
  user_id    uuid not null references auth.users (id),
  title      text not null,
  done       boolean not null default false
);

-- Invoices: "admin only", checked against user_metadata (users can edit it).
create table public.invoices (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users (id),
  amount_inr integer not null
);
alter table public.invoices enable row level security;
create policy "admins read invoices" on public.invoices
  for select to authenticated
  using ((auth.jwt() -> 'user_metadata' ->> 'role') = 'admin');

-- A dashboard view. Views run as their owner, so this ignores RLS.
create view public.project_stats as
  select p.id as project_id, p.owner_id, p.name, count(t.id) as task_count
  from public.projects p left join public.tasks t on t.project_id = p.id
  group by p.id;

-- An RPC helper that deletes a project. SECURITY DEFINER bypasses RLS, and it
-- never checks who is calling. Callable by anyone via supabase.rpc().
create function public.delete_project(p_id uuid) returns void
language sql security definer as $$
  delete from public.projects where id = p_id;
$$;

-- Storage: user uploads in a public bucket, and an upload policy that doesn't
-- check whose folder the file goes into.
insert into storage.buckets (id, name, public) values ('uploads', 'uploads', true);
create policy "logged in users upload" on storage.objects
  for insert to authenticated with check (bucket_id = 'uploads');

-- Demo data.
insert into public.profiles (id, display_name, email) values
  ('00000000-0000-0000-0000-00000000000a', 'Asha', 'asha@example.com'),
  ('00000000-0000-0000-0000-00000000000b', 'Ben',  'ben@example.com');
insert into public.projects (id, owner_id, name) values
  ('10000000-0000-0000-0000-00000000000a', '00000000-0000-0000-0000-00000000000a', 'Asha''s launch plan'),
  ('10000000-0000-0000-0000-00000000000b', '00000000-0000-0000-0000-00000000000b', 'Ben''s client work');
insert into public.tasks (project_id, user_id, title) values
  ('10000000-0000-0000-0000-00000000000a', '00000000-0000-0000-0000-00000000000a', 'Finalise pricing'),
  ('10000000-0000-0000-0000-00000000000a', '00000000-0000-0000-0000-00000000000a', 'Email beta users'),
  ('10000000-0000-0000-0000-00000000000b', '00000000-0000-0000-0000-00000000000b', 'Send invoice to client');
insert into public.invoices (user_id, amount_inr) values
  ('00000000-0000-0000-0000-00000000000a', 4999),
  ('00000000-0000-0000-0000-00000000000b', 12000);
