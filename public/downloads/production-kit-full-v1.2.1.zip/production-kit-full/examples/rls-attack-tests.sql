-- ============================================================================
-- Attack tests for the demo schema. Each block pretends to be someone and
-- tries something they shouldn't be able to do. Every block ends in
-- ROLLBACK, so nothing is changed.
--
-- Run each block separately in the SQL Editor (or the whole file with psql).
-- Run once before the fix and once after, and compare.
--
-- Demo users: Asha = ...000a, Ben = ...000b.
-- ============================================================================

-- T1. A logged-out visitor (anyone with your public anon key).
begin;
  set local role anon;
  select 'T1a anon reads tasks'            as test, count(*)::text as result from public.tasks;
  select 'T1b anon reads emails'           as test, coalesce(string_agg(to_jsonb(p) ->> 'email', ', '), 'no email column') as result from public.profiles p;
  select 'T1c anon reads project_stats'    as test, count(*)::text as result from public.project_stats;
  select 'T1d anon calls delete_project on Ben''s project' as test, 'called' as result
    from (select public.delete_project('10000000-0000-0000-0000-00000000000b')) as call;
  reset role;  -- look as the database owner: how many projects are left?
  select 'T1e projects left after T1d (was 2)' as test, count(*)::text as result from public.projects;
rollback;

-- Ben, logged in, for the tests below.
-- T2. Ben edits Asha's project.
begin;
  set local role authenticated;
  select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-00000000000b","role":"authenticated"}', true);
  with changed as (
    update public.projects set name = 'renamed by Ben'
    where owner_id = '00000000-0000-0000-0000-00000000000a' returning 1)
  select 'T2 Ben renames Asha''s project' as test, count(*)::text || ' row(s) changed' as result from changed;
rollback;

-- T3. Ben reads Asha's tasks.
begin;
  set local role authenticated;
  select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-00000000000b","role":"authenticated"}', true);
  select 'T3 Ben reads tasks (he owns 1)' as test, count(*)::text || ' task(s) visible' as result from public.tasks;
rollback;

-- T4. Ben makes himself an admin.
begin;
  set local role authenticated;
  select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-00000000000b","role":"authenticated"}', true);
  with changed as (
    update public.profiles set role = 'admin'
    where id = '00000000-0000-0000-0000-00000000000b' returning role)
  select 'T4 Ben sets his own role' as test, coalesce(max(role), 'blocked (0 rows)') as result from changed;
rollback;

-- T5. Ben edits his own user_metadata (any user can, with
--     supabase.auth.updateUser({ data: { role: "admin" } })) and reads invoices.
begin;
  set local role authenticated;
  select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-00000000000b","role":"authenticated","user_metadata":{"role":"admin"}}', true);
  select 'T5 Ben reads invoices after editing user_metadata' as test, count(*)::text || ' invoice(s) visible' as result from public.invoices;
rollback;

-- T6. Ben uploads a file into Asha's folder.
begin;
  set local role authenticated;
  select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-00000000000b","role":"authenticated"}', true);
  insert into storage.objects (bucket_id, name, owner)
  values ('uploads', '00000000-0000-0000-0000-00000000000a/avatar.png', '00000000-0000-0000-0000-00000000000b');
  select 'T6 Ben uploads into Asha''s folder' as test, 'allowed' as result;
rollback;

-- T7. Asha still works normally (a fix must not break the real app).
begin;
  set local role authenticated;
  select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-00000000000a","role":"authenticated"}', true);
  select 'T7a Asha reads her projects' as test, count(*)::text as result from public.projects;
  select 'T7b Asha reads her tasks'    as test, count(*)::text as result from public.tasks;
  with changed as (update public.projects set name = 'Launch plan v2' where owner_id = '00000000-0000-0000-0000-00000000000a' returning 1)
  select 'T7c Asha renames her project' as test, count(*)::text || ' row(s) changed' as result from changed;
  insert into storage.objects (bucket_id, name, owner)
  values ('uploads', '00000000-0000-0000-0000-00000000000a/avatar.png', '00000000-0000-0000-0000-00000000000a');
  select 'T7d Asha uploads into her folder' as test, 'allowed' as result;
rollback;

begin;
  set local role authenticated;
  select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-00000000000a","role":"authenticated"}', true);
  with changed as (update public.profiles set display_name = 'Asha K' where id = '00000000-0000-0000-0000-00000000000a' returning 1)
  select 'T7e Asha changes her display name' as test, count(*)::text || ' row(s) changed' as result from changed;
rollback;
