# Changelog

## 1.2.1 (2026-09-28)

### Changed
- The kit is free. `LICENSE` now lets anyone use it, including for client work, and share it for free with credit; selling it is still not allowed. The README's License and Updates sections say the same.
- No changes to the rules, skills, templates, checklists or SQL.

## 1.2.0 (2026-09-24)

### Added
- `plan-feature` skill: plan a new feature before any code is written (goal and scope, data with owner columns, access rules that become RLS, server-side logic, pages with loading/empty/error states, edge cases, acceptance criteria, small build steps), and get approval first.
- `slop-check` skill: review changes for unfinished work presented as done, invented packages or APIs, duplicates and dead code, over-engineering, noisy comments, the generic AI look, placeholder content and filler copy. Includes the exact searches to run.
- CLAUDE.md sections 10 to 12: planning before building, UI quality, and no AI slop.
- Cursor rules: `no-slop.mdc` (always on) and `ui-quality.mdc` (components and styles); planning added to `change-discipline.mdc`.
- Lovable/Bolt: planning, UI and no-slop rules in both knowledge files; guided prompts for planning a feature (section 0) and a slop check (section 6).
- Launch checklist section 12 (code and content quality). `safe-change` now points to `plan-feature` for new features, and `pre-deploy-check` checks for placeholder content.

### If you installed an earlier version
Copy `CLAUDE.md` and the `skills/` folder over your old ones (and `cursor-rules/` into `.cursor/rules/` for Cursor). If you merged the kit's CLAUDE.md into your own, add sections 10 to 12. For Lovable or Bolt, replace your project knowledge with the new file.

## 1.1.0 (2026-09-24)

### Fixed
- The SQL files now install with the skills. They moved from `sql/` to `skills/supabase-rls-audit/sql/`, so when the RLS audit and auth skills refer to `rls-status.sql` or `example-policies.sql`, the files are actually in your project after install. Before, the install steps didn't copy them.
- The Cursor install now copies the skills (and the SQL) into `.cursor/skills/`, and the README shows how to reference them.
- Updated every path in the README, checklists and skills to match.

### Added
- `templates/`: drop-in files for Vite + React and Next.js (Supabase client, auth provider, route guard, email confirm and password reset pages, error boundary, env checks, `@supabase/ssr` setup with `proxy.ts`, secret-key admin client, Stripe webhook with billing migration, robots.txt, sitemap script, Vercel and Netlify rewrites). Typecheck and production build pass against @supabase/supabase-js 2.117, @supabase/ssr 0.12, Next.js 16.3, React 19, React Router 7, Vite 8 and stripe 22.
- `examples/`: a sample RLS audit of a deliberately insecure demo app, with the demo schema, the report, the fix migration and before/after attack tests (run on Postgres 16).
- `lovable-bolt-instructions-full.md`: a fuller project-knowledge file for Lovable and Bolt.
- `lovable-bolt-prompts.md`: step-by-step prompts that take Lovable or Bolt through the same checks as the Claude Code skills.
- `LICENSE`: what you can and can't do with the kit.
- This changelog, and a version number in the README.

### If you installed 1.0.0
Copy the new `skills/` folder over your old one (`.claude/skills/` or `.cursor/skills/`). The new files are optional additions; nothing else needs to change.

## 1.0.0

- First release: CLAUDE.md, five Claude Code skills, Cursor rules, Lovable/Bolt instructions, launch and security checklists, RLS status queries and example policies.
