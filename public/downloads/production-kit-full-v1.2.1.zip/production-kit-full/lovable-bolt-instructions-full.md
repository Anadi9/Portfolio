# Production rules (Supabase + React), full version

## Security
- Only the Supabase anon/publishable key may appear in frontend code or in VITE_/NEXT_PUBLIC_ variables. The secret/service_role key bypasses all security: use it only in Edge Functions or server routes. If you ever see a secret key in frontend code, stop and tell me; it must be rotated, not just deleted.
- Anything with the VITE_ or NEXT_PUBLIC_ prefix is public, because it's copied into the JavaScript every visitor downloads.
- Every table in the public schema has RLS enabled, in the same migration that creates it, with its policies. No exceptions for "internal" tables.
- Write policies as (select auth.uid()) = user_id, not bare auth.uid(). Name the role on every policy: to authenticated, or to anon only for data that is meant to be public.
- Update policies need both using and with check, so users can't hand a row to someone else by changing user_id.
- Insert policies use with check ((select auth.uid()) = user_id). Default user_id to auth.uid() in the table; never trust a user_id sent from the browser.
- Never use true in a policy for insert, update or delete. using (true) for select only when the data really is public.
- RLS hides rows, not columns. Keep private columns (email, phone, address, billing) out of publicly readable tables; put them in an owner-only table.
- Users must not be able to change their own role, plan, credits or is_admin. Keep those in a table users can't write, or restrict updates to specific columns.
- Never authorize with user_metadata: users can edit it. For admin checks use app_metadata or a roles table.
- Views bypass RLS unless created with (security_invoker = true). security definer functions bypass RLS: avoid them in public; when needed, set search_path = '', check auth.uid() inside, and revoke execute from anon.
- Storage: user uploads go in private buckets, served with signed URLs. Upload paths start with the user id (userId/filename). Policies check both the bucket and that the first folder equals auth.uid(). Set a max file size and allowed file types.
- Never trust prices, discounts, roles or permissions sent from the browser. Decide them in the database or an Edge Function. Stripe webhooks must verify the signature.
- Validate input size and shape in Edge Functions. Never return raw database errors or stack traces to the browser.

## Auth
- Pass emailRedirectTo or redirectTo, built from window.location.origin, on every sign-up, magic link, password reset and OAuth call. Every URL used must be in Supabase > Authentication > URL Configuration > Redirect URLs, and Site URL must be the production domain.
- With email confirmation on, sign-up returns no session. Show "check your email"; don't navigate into the app.
- If sign-up returns a user with an empty identities list, the email is already registered: show "check your email or log in".
- Use one Supabase client for the whole app (one module, imported everywhere).
- Subscribe to onAuthStateChange once at the app root and unsubscribe on unmount. Don't await other Supabase calls inside the callback; it can freeze auth.
- Protected pages show a loading state until the first session check finishes. Never redirect to login while loading.
- The password reset page calls supabase.auth.updateUser({ password }). Route guards must not redirect it away.
- Email links: prefer a /auth/confirm page that reads token_hash and type from the URL and calls verifyOtp when the user clicks a button. It survives email scanners and different devices.
- Show a human message when the URL contains error_description (expired or used links).
- Create profile rows with a database trigger on auth.users, not from the browser after sign-up.
- Production needs custom SMTP for auth emails; the built-in sender is for testing only.

## Environment variables
- Keep a .env.example with every variable name and no values. Never commit real .env files.
- Read env vars in one place and show a clear error if a required one is missing.
- Changing a VITE_ variable needs a rebuild and redeploy.

## Data
- Every schema change is a migration. Never drop or rename columns or tables, or change their type, without asking me first and telling me what data would be lost.
- Index foreign keys and every column used in filters or policies (user_id, team_id, created_at).
- Use uuid ids, timestamptz dates, not null and check constraints where they apply.
- Check error on every Supabase call. Never read only data.
- Every screen that loads data has a loading state, an error state and an empty state.
- Disable submit buttons while saving, so double clicks don't create duplicates.
- Select only the columns needed. Paginate lists; never load a whole table.
- Use joins (embedded selects) instead of queries inside loops.

## Deploy
- For Vercel, keep vercel.json rewriting /(.*) to /index.html so refreshing a page doesn't 404. For Netlify, public/_redirects with /* /index.html 200.
- Have a real 404 page and an error boundary around the app, so a crash shows a message instead of a white screen.
- Remove console.log calls that print user data or tokens.

## Performance
- Lazy-load routes. Import named icons and functions, not whole libraries.
- Images: sized for display, WebP, with width and height set, lazy-loaded below the fold.
- Load independent data in parallel.

## SEO (public pages)
- Each public page has a unique title (under 60 characters), meta description, canonical URL and Open Graph tags including an absolute og:image.
- One h1 per page. Navigation uses real links (a href), not clickable divs.
- robots.txt and sitemap.xml at the site root. Logged-in pages are noindex.
- A client-rendered app shows crawlers an empty page. For pages that must be found, prerender them or render them on the server, and tell me the options before changing the build.

## Planning new features
- For a new feature, page or flow, show me a short plan first and wait for my OK: the goal and what's out of scope, the user flow, tables and columns with the owner column, who can see, create, edit and delete each table (this becomes the RLS policies), what must run in an Edge Function, each page with its loading, empty and error states, edge cases, how we'll test it, and small build steps that each leave the app working.
- Search for existing components, hooks, tables and functions before creating new ones, and tell me what you're reusing.
- If the code turns out different from the plan, stop and tell me instead of building something else.

## UI quality
- Use the existing design system: Tailwind theme, CSS variables, shadcn/ui components. No hardcoded hex colours, arbitrary pixel values or one-off font sizes. If a value is missing, add it to the theme once.
- Few, consistent variants: one primary, one secondary and one destructive button style; a small set of font sizes and spacing values; one icon set. Never create a second Button, Modal or Card.
- Every button and link has hover, focus, disabled and loading states. Never remove focus outlines without a visible replacement.
- Works at 375px wide, tap targets at least 44px, readable contrast.
- Let the content decide the layout. Don't default to a centred hero with three identical cards, purple-to-pink gradients, glass effects, emoji as icons or animation everywhere unless I ask for it.

## No AI slop
- Never present unfinished work as done: no stubs, hardcoded results, TODOs, fake success when a request fails, or mock data in real screens. Tell me what isn't finished.
- Only use packages that are installed and functions that really exist in them. Ask me before adding a package.
- One Supabase client and one version of each component and helper. No extra layers or files for something used once.
- Delete what you replace: no commented-out code, unused files or debug logs.
- Real content only: no lorem ipsum, invented testimonials, user counts, ratings or customer logos. Use an obvious placeholder like [Add testimonial] and list them for me.
- Copy is plain and specific. Buttons say what they do ("Save changes", not "Submit"). Errors say what to do next. No filler words like unlock, seamless, revolutionise, elevate or supercharge.

## How to change code
- Before fixing a bug, say how to reproduce it and what the cause is. If you can't reproduce it, say so and ask me for details instead of guessing.
- Make the smallest change that solves the request. Don't rewrite, restyle, rename, restructure or upgrade anything I didn't ask about.
- Don't remove features or code you don't understand. Ask.
- If a fix needs a bigger change, explain why and ask first.
- For security or database work, list the problems first and wait for my approval before changing anything.
- After each change, tell me: what changed and why, what to test (as a logged-out visitor and as a second user when data access changed), and anything I must do in Supabase, Vercel, Netlify or Stripe settings.
- List other problems you noticed at the end instead of fixing them silently.
