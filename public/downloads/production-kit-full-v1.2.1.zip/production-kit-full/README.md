# The Production Kit

by Anadi Thakur · Version 1.2.0 ([changelog](CHANGELOG.md))

Rules, skills and checklists that make your AI coding tool (Claude Code, Cursor, Lovable, Bolt) write safer production code for React/Next.js + Supabase apps, plus checklists so you can verify the result yourself.

It's for founders and builders who ship with AI tools and whose app works on localhost but breaks, leaks or stalls once real users arrive.

## What's inside

| File | What it does |
|---|---|
| `CLAUDE.md` | Project instructions for Claude Code: security, Supabase RLS, auth, env vars, deployment, data, errors, performance, SEO, how to change code without breaking it, planning new features, UI quality, and no AI slop. |
| `skills/` | Seven Claude Code skills: step-by-step procedures the agent follows when the task comes up. |
| `cursor-rules/` | The same core rules as Cursor `.mdc` rule files. |
| `lovable-bolt-instructions.md` | A condensed version (about 2,600 characters) to paste into Lovable or Bolt. |
| `lovable-bolt-instructions-full.md` | The fuller version (about 9,000 characters; Lovable allows up to 10,000, so this leaves about 1,000 for your own). Use the short one if you need more room. |
| `lovable-bolt-prompts.md` | Step-by-step prompts that walk Lovable or Bolt through the same procedures as the skills: planning a feature, database security, secrets, auth, pre-launch, SEO, slop check. |
| `templates/` | Drop-in code: Supabase client, auth provider and route guard, email confirm and password reset pages, error boundary, env checks, Next.js server setup, Stripe webhook, robots.txt, sitemap script, SPA rewrites. See `templates/README.md`. |
| `examples/` | A sample RLS audit of a deliberately insecure demo app: the schema, the findings report, the fix migration and before/after attack tests. |
| `checklists/launch-checklist.md` | Everything to verify before real users, grouped by area. |
| `checklists/security-checklist.md` | Security checks, each with how to check it. |
| `skills/supabase-rls-audit/sql/rls-status.sql` | Read-only queries: which tables have RLS, every policy, risky views/functions, storage, missing indexes. |
| `skills/supabase-rls-audit/sql/example-policies.sql` | Copyable RLS policies: owner-only, public read/own write, team membership, per-user storage folders. |
| `LICENSE` | What you can and can't do with the kit. |
| `CHANGELOG.md` | What changed in each version. |

The skills:
- **supabase-rls-audit**: find tables anyone can read or write, fix the policies, and test as a logged-out visitor and as a second user.
- **pre-deploy-check**: env vars, build, SPA routing, auth redirect URLs, error pages, console errors, Lighthouse basics.
- **auth-flow-fix**: diagnose sign-up, login, email confirmation, password reset, OAuth and session problems.
- **ai-visibility**: make a client-rendered app readable by Google, link previews and AI crawlers (prerendering, meta tags, sitemap, robots.txt, JSON-LD), verified with curl.
- **safe-change**: the working discipline for changes: checkpoint, reproduce, smallest diff, verify, commit.
- **plan-feature**: before building anything new, a short plan you approve: data, who can access what (RLS), pages and their states, edge cases, acceptance criteria and small build steps.
- **slop-check**: reviews changes for work that looks done but isn't, invented packages or APIs, duplicates, dead code, over-engineering, the generic AI look, placeholder content and filler copy, with the exact searches to run.

## Install: Claude Code

From your project's root folder (adjust the path to where you unzipped the kit):

```bash
# 1. Project instructions
cp ~/Downloads/production-kit/CLAUDE.md ./CLAUDE.md

# 2. Skills
mkdir -p .claude/skills
cp -R ~/Downloads/production-kit/skills/* .claude/skills/
```

If you already have a `CLAUDE.md`, don't overwrite it: paste the kit's content below yours and remove anything that contradicts your project.

You should end up with `.claude/skills/supabase-rls-audit/SKILL.md` and so on. The SQL files install with the RLS audit skill, at `.claude/skills/supabase-rls-audit/sql/`, so the skills can find them in your project. Claude uses a skill automatically when your request matches its description, or you can call one directly, e.g. `/supabase-rls-audit`. To use the skills in every project, copy them to `~/.claude/skills/` instead.

Commit `CLAUDE.md` and `.claude/skills/` so they stay with the project.

## Install: Cursor

```bash
# 1. Rules
mkdir -p .cursor/rules
cp ~/Downloads/production-kit/cursor-rules/*.mdc .cursor/rules/

# 2. Skills (and the SQL files, which live inside the RLS audit skill)
mkdir -p .cursor/skills
cp -R ~/Downloads/production-kit/skills/* .cursor/skills/
```

- `security.mdc`, `change-discipline.mdc` (including planning new features) and `no-slop.mdc` apply to every request.
- `supabase.mdc`, `deploy.mdc` and `ui-quality.mdc` attach automatically when you work on matching files (SQL, Supabase client, config, env files, components and styles). Edit the `globs:` line if your folders are named differently.

To use a skill in Cursor, mention it in chat, e.g. "Follow @.cursor/skills/supabase-rls-audit/SKILL.md for this project". When a skill mentions a file in its folder (like `sql/rls-status.sql`), it's in that skill's folder under `.cursor/skills/`.

## Install: Lovable and Bolt

Open `lovable-bolt-instructions-full.md` (or the shorter `lovable-bolt-instructions.md` if you need room for your own instructions), copy everything, and paste it into:
- **Lovable**: your project's settings, under Knowledge (project knowledge / custom instructions).
- **Bolt**: your project's settings, under the project prompt / knowledge section.

Menu names in these tools change often; look for the place where you give the AI standing instructions for the project. It applies to future prompts, not to code already written, so after adding it, ask the tool to review existing code against these rules, one area at a time (e.g. "Check every Supabase table has RLS enabled per the project knowledge; list problems before changing anything").

Then work through `lovable-bolt-prompts.md`: copy-paste prompts, in order, that take Lovable or Bolt through a database security audit, a secrets check, auth fixes, a pre-launch check and SEO, with the Supabase steps you do yourself spelled out.

## Other tools

Codex, Windsurf and other agents that read `AGENTS.md`: copy `CLAUDE.md` to `AGENTS.md` in your repo root.

## Using the checklists

Work through `checklists/launch-checklist.md` before you invite real users, and `checklists/security-checklist.md` before launch and after any big change to your database or auth. Test on your deployed site, not just localhost.

## Using the templates

`templates/` has ready-made files for Vite + React and Next.js apps. Each file starts with a comment saying where it goes. Copy only what you need, or paste a file into your AI tool's chat and ask it to adapt it to your project. `templates/README.md` lists every file.

## See a sample audit

`examples/rls-audit-sample-report.md` shows what the RLS audit finds on a deliberately insecure demo app, with the fix and before/after test results. The demo schema, fix and tests are in the same folder if you want to run them on a throwaway Supabase project.

## Using the SQL

Open Supabase Dashboard > SQL Editor, paste one query at a time from `skills/supabase-rls-audit/sql/rls-status.sql` and run it. It only reads; it changes nothing. For `skills/supabase-rls-audit/sql/example-policies.sql`, copy only the pattern you need, rename the tables and columns to match yours, and run it as a migration. Read the comments first.

## Limits

This kit reduces the most common production failures. It doesn't guarantee your app is secure or bug-free: the AI can still make mistakes, and the checklists only help if you actually run them. For anything handling payments, health or other sensitive data, get a human review.

## Updates

The kit is free, and the latest version is always at https://anadithakur.in/products/production-kit. There's no promise of future updates. `CHANGELOG.md` lists what changed in each version.

## License

Free to use in any number of projects, including client work, and free to share with anyone as long as you keep the LICENSE and credit the source. Don't sell it. Full terms: [LICENSE](LICENSE).

Questions or problems with the kit: contact via https://anadithakur.in
